# World/interaction_engine.py
from __future__ import annotations
from dataclasses import replace
from typing import Any, Dict, Tuple

from World.state import WorldState
from World.interactions import Interaction
from World.results import ToolResult
from World.engine import emit, advance_turn, append_events
from World.events import Event

def _new_interaction_id(state: WorldState) -> Tuple[WorldState, str]:
    n = int(getattr(state, "next_interaction_id", 1) or 1)
    new_state = replace(state, next_interaction_id=n + 1)
    return new_state, f"i{n}"

def talk_request(state: WorldState, *, initiator: str, target: str, room_id: str) -> Tuple[WorldState, ToolResult]:
    # must be co-located
    if state.locations.get(initiator) != room_id or state.locations.get(target) != room_id:
        return state, ToolResult(False, "Talk request requires both actors to be in the same room.")

    # basic: deny if either is already in active talk
    for it in (getattr(state, "interactions", {}) or {}).values():
        if it.kind == "talk" and it.status == "active":
            if initiator in (it.initiator, it.target) or target in (it.initiator, it.target):
                return state, ToolResult(False, "Denied: someone is already in an active conversation.")

    state, iid = _new_interaction_id(state)
    interactions = dict(getattr(state, "interactions", {}) or {})
    inter = Interaction(
        id=iid,
        kind="talk",
        initiator=initiator,
        target=target,
        room_id=room_id,
        status="pending",
        created_turn=state.turn,
        messages=tuple(),
    )
    interactions[iid] = inter
    state = replace(state, interactions=interactions)

    state, ev = emit(state, actor=initiator, type="talk_request", args={"target": target, "room_id": room_id, "interaction_id": iid}, ok=True, message="talk requested")
    advanced = advance_turn(state)
    return advanced, ToolResult(True, f"OK: {initiator} requested to talk with {target}.", events=(ev,), data={"interaction_id": iid})

def talk_accept(state: WorldState, *, who: str, interaction_id: str) -> Tuple[WorldState, ToolResult]:
    interactions = dict(getattr(state, "interactions", {}) or {})
    inter = interactions.get(interaction_id)
    if not inter:
        return state, ToolResult(False, f"Unknown interaction: {interaction_id}")
    if inter.kind != "talk":
        return state, ToolResult(False, "Not a talk interaction.")
    if inter.status != "pending":
        return state, ToolResult(False, f"Invalid state: {inter.status}")
    if who != inter.target:
        return state, ToolResult(False, f"Denied: only {inter.target} can accept this talk request.")
    if state.locations.get(inter.initiator) != inter.room_id or state.locations.get(inter.target) != inter.room_id:
        return state, ToolResult(False, "Talk no longer possible: not in the same room.")

    interactions[interaction_id] = replace(inter, status="active")
    state = replace(state, interactions=interactions)
    state, ev = emit(state, actor=who, type="talk_accept", args={"interaction_id": interaction_id}, ok=True, message="talk accepted")
    advanced = advance_turn(state)
    return advanced, ToolResult(True, f"OK: talk started between {inter.initiator} and {inter.target}.", events=(ev,))

def talk_decline(state: WorldState, *, who: str, interaction_id: str) -> Tuple[WorldState, ToolResult]:
    interactions = dict(getattr(state, "interactions", {}) or {})
    inter = interactions.get(interaction_id)
    if not inter:
        return state, ToolResult(False, f"Unknown interaction: {interaction_id}")
    if inter.kind != "talk":
        return state, ToolResult(False, "Not a talk interaction.")
    if inter.status != "pending":
        return state, ToolResult(False, f"Invalid state: {inter.status}")
    if who != inter.target:
        return state, ToolResult(False, f"Denied: only {inter.target} can decline this talk request.")

    interactions[interaction_id] = replace(inter, status="declined")
    state = replace(state, interactions=interactions)
    state, ev = emit(state, actor=who, type="talk_decline", args={"interaction_id": interaction_id}, ok=True, message="talk declined")
    advanced = advance_turn(state)
    return advanced, ToolResult(True, f"OK: {who} declined the talk request.", events=(ev,))

def talk_say(state: WorldState, *, who: str, interaction_id: str, text: str) -> Tuple[WorldState, ToolResult]:
    interactions = dict(getattr(state, "interactions", {}) or {})
    inter = interactions.get(interaction_id)
    if not inter:
        return state, ToolResult(False, f"Unknown interaction: {interaction_id}")
    if inter.kind != "talk":
        return state, ToolResult(False, "Not a talk interaction.")
    if inter.status != "active":
        return state, ToolResult(False, f"Invalid state: {inter.status}")
    if who not in (inter.initiator, inter.target):
        return state, ToolResult(False, "Denied: you are not a participant in this talk.")
    if state.locations.get(inter.initiator) != inter.room_id or state.locations.get(inter.target) != inter.room_id:
        return state, ToolResult(False, "Talk ended: participants are no longer in the same room.")

    msg = {"speaker": who, "text": text, "turn": state.turn}
    interactions[interaction_id] = replace(inter, messages=inter.messages + (msg,))
    state = replace(state, interactions=interactions)
    state, ev = emit(state, actor=who, type="talk_say", args={"interaction_id": interaction_id, "text": text}, ok=True, message="said something")
    advanced = advance_turn(state)
    return advanced, ToolResult(True, f"{who}: {text}", events=(ev,))
