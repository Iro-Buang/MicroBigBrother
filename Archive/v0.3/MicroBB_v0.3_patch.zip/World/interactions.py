# World/interactions.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Tuple, Any, Literal

InteractionStatus = Literal["pending", "active", "declined", "closed"]

@dataclass(frozen=True)
class Interaction:
    id: str
    kind: str                       # e.g. "talk"
    initiator: str
    target: str
    room_id: str
    status: InteractionStatus = "pending"
    created_turn: int = 0
    messages: Tuple[Dict[str, Any], ...] = field(default_factory=tuple)  # {"speaker":..., "text":..., "turn":...}

