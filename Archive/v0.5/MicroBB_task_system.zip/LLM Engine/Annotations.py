from npcframework.npcframework_types import TurnInput, EngineConfig
print(TurnInput.__annotations__)
print(EngineConfig.__annotations__)